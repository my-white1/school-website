<?php $__env->startSection('content'); ?>
    <?php
        $a = \App\Models\About::find(1);
        $classes = \App\Models\Classes::all();
    ?>
    <section class="about-page-content">
        <div class="container">
            <div class="abt-page-row">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="section-title">
                            <h2><span><?php echo e($a->name); ?></span> ga <br> hush kelibsiz</h2>
                            <p class="mw-100"><?php echo e($a->description); ?>



                                vestibulum leo sagittis et.</p><a href="<?php echo e(route('classes.index')); ?>" title=""
                                class="btn-default">Classes <i class="fa fa-long-arrow-alt-right"></i></a>
                        </div>
                        <!--section-title end-->
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="avt-img"><img width="500" height="500" src="<?php echo e(asset("images/$a->image")); ?>"
                                alt=""></div>
                        <!--avt-img end-->
                    </div>
                </div>

            </div>
            <!--abt-page-row end-->
        </div>
    </section>
    <!--main-banner end-->
    <!--about-us-section end-->
    <section class="classes-section">
        <div class="container">
            <div class="sec-title">
                <h2>Bizning sinflarimiz</h2>
                <p>Bizning kichik sinflarimiz guruhlar ichida jonli muloqot qilish imkonini beradi va shu bilan
                    o'quvchilarimizning o'rganish natijalarini optimallashtiradigan</p>
            </div>
            <!--sec-title end-->
            <div class="classes-sec">
                <div class="row classes-carousel">
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3">
                            <div class="classes-col wow fadeInUp" data-wow-duration="1000ms">
                                <div class="class-thumb"><img src="<?php echo e(asset('images/' . $class->image)); ?>" alt=""
                                        class="w-100">

                                </div>
                                <div class="class-info">
                                    <h3><a href="<?php echo e(route('class.detail', $class->id)); ?>"
                                            title=""><?php echo e($class->number); ?>-<?php echo e($class->name); ?>

                                            Sinf</a></h3>
                                    <span>Xar kuni</span> <span></span>
                                    <div class="d-flex flex-wrap align-items-center">
                                        <div class="posted-by"><img style="width: 30px; height: 30px"
                                                src="<?php echo e(asset('images/' . $class->teacher->image)); ?>" alt="">
                                            <a href="assets/images/resources/bg4.jpg.html#"
                                                title=""><?php echo e($class->teacher->firstname); ?>

                                                <?php echo e($class->teacher->lastname); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--classes-col end-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="lnk-dv text-center"><a href="<?php echo e(route('classes.index')); ?>" title=""
                        class="btn-default">Classes <i class="fa fa-long-arrow-alt-right"></i></a></div>
            </div>
            <!--classes-sec end-->
        </div>
    </section>
    <!--classes-section end-->
    <section class="teachers-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Bizning ajoyib<br>O'qtuvchilar</h2>
                <p>"Yaxshi o'qituvchi umidni ilhomlantirishi, tasavvurni yoqishi va o'rganishga muhabbat uyg'otishi mumkin."
                </p>
            </div>
            <!--section-title end-->
            <div class="teachers">
                <div class="row">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-6 full-wdth">
                            <div class="teacher">
                                <div class="teacher-img"><img style="width: 235px; height: 425px;"
                                        src="<?php echo e(asset("images/$teacher->image")); ?>" alt="" class="w-100">

                                </div>
                                <div class="teacher-info">
                                    <h3><a href="teacher-single.html" title=""><?php echo e($teacher->firstname); ?>

                                            <?php echo e($teacher->lastname); ?></a></h3>
                                    <span><?php echo e($teacher->category); ?> O`qituvchisi</span>
                                </div>
                            </div>
                            <!--teacher end-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!--teachers end-->
        </div>
    </section>
    <section class="course-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="find-course">
                        <div class="sec-title">
                            <h2>Kursingizni toping</h2>
                            <p>Qaysi fan, kurs turi yoki universitet yoki kollej sizga mos kelishini hal qilmayapsizmi?
                                Ushbu muhim qarorni hal qilish bo'yicha maslahatlarimiz va maslahatlarimizni o'qing</p>
                            <h3><img src="assets/img/icon11.png" alt="">Bog'lanish uchun: <strong>+998
                                    <?php echo e($a->phone_number); ?>

                                </strong></h3>
                        </div>
                        <!--sec-title end-->
                        <div class="course-img"><img src="assets/img/course-img.png" alt=""></div>
                        <!--course-img end-->
                    </div><a href="<?php echo e(route('course.index')); ?>" title=""
                        style="color: #044e7c
                                 " class="read-more text-bg-primary">Ko`proq
                        <i class="fa fa-long-arrow-alt-right"></i></a>
                    <!--find-course end-->
                </div>
                
                <div class="col-lg-6">
                    <div class="courses-list">
                        <!--course-card end-->
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="course-card wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="400ms">
                                <div class="d-flex flex-wrap align-items-center">
                                    <ul class="course-meta">
                                        <li><img src="assets/img/icon12.png" alt="">
                                            
                                        <li><?php echo e($course->start_time); ?> - <?php echo e($course->end_time); ?></li>
                                    </ul><span><?php echo e($course->price); ?> UZS </span>
                                </div>
                                <h3><a href="<?php echo e(route('course.detail', $course->id)); ?>"
                                        title=""><?php echo e($course->name); ?></a></h3>
                                <div class="d-flex flex-wrap">
                                    <div class="posted-by"><img style="width: 10%"
                                            src="<?php echo e(asset("images/$course->image")); ?>" alt="Class image"> <a
                                            href="<?php echo e(asset('images/' . $course->teacher->image)); ?>"
                                            title=""><?php echo e($course->teacher->firstname); ?>

                                            <?php echo e($course->teacher->firstname); ?></a></div><span class="locat"><img
                                            src="assets/img/loct.png" alt=""><?php echo e($a->name); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
    <!--course-section end-->
    <section class="blog-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>So'nggi yangiliklar</h2>
                <p>Biz haqimizdagi eng sara so'nggi yangiliklar haqida bilib oling</p>
            </div>
            <!--section-title end-->
            <div class="blog-posts">
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="blog-post">


                                <div class="blog-thumbnail"><img style="width: 369px; height: 246px"
                                        src="<?php echo e(asset('images/' . $blog->image)); ?>" alt="" class="w-100">

                                    <span class="category"><?php echo e($blog->title); ?></span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li><a href="assets/images/resources/bg4.jpg.html#" title=""></a>
                                        </li>
                                        <li><a href="assets/images/resources/bg4.jpg.html#" title="">by
                                                Admin</a></li>
                                        <li><img src="assets/img/icon13.png" alt=""><a
                                                href="assets/images/resources/bg4.jpg.html#"
                                                title=""><?php echo e($blog->category->name); ?>,</a><a
                                                href="assets/images/resources/bg4.jpg.html#" title="">
                                                School</a></li>
                                    </ul>
                                    <h3><a href="<?php echo e(route('blog.show', $blog->id)); ?>"
                                            title=""><?php echo e($blog->title); ?></a></h3>
                                    <p><?php echo e(substr($blog->description, 0, 25)); ?>...
                                    </p><a href="<?php echo e(route('blog.show', $blog->id)); ?>" title=""
                                        class="read-more">Read <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                            <!--blog-post end-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!--blog-posts end-->
        </div>
    </section>
    <!--blog-section end-->
    <!--newsletter-sec end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/frontend/home/index.blade.php ENDPATH**/ ?>
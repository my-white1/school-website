<div class="classes-section">
    <div class="classes-sec">
        <div class="row">
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="classes-col">
                        <div class="class-thumb"><img src="<?php echo e(asset("images/$class->images")); ?>" alt=""
                                class="w-100">
                        </div>
                        <div class="class-info">
                            <h3><a href="<?php echo e(route('class.detail', $class->id)); ?>"
                                    title=""><?php echo e($class->number); ?>-<?php echo e($class->name); ?> Sinf</a>
                            </h3>
                            <span>Xarkuni</span> <span></span>
                            <div class="d-flex flex-wrap align-items-center">
                                <?php
                                    $image = $class->teacher->image;
                                ?>
                                <div class="posted-by"><img style="width: 30px; height: 30px" src="<?php echo e(asset("images/$image")); ?>" alt="">
                                    <a href="classes.html#" title=""><?php echo e($class->teacher->firstname); ?>

                                        <?php echo e($class->teacher->lastname); ?></a></div>
                            </div>
                        </div>
                    </div>
                    <!--classes-col end-->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!--classes-sec end-->
    <div class="mdp-pagiation">
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li  class="page-item"><a wire:click="viewMore" class="page-link" role="button" type="button">Yana</a></li>
            </ul>
        </nav>
        
    </div>
    <!--pagination-end-->


</div>
<?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/livewire/fronend/classes-table.blade.php ENDPATH**/ ?>
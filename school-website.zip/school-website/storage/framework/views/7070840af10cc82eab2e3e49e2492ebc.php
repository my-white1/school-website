<div class="row vh-100">
    <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
        <div class="d-table-cell align-middle">

            <div class="text-center mt-4">
                <h1 class="h2">Welcome back, Charles</h1>
                <p class="lead">
                    Sign in to your account to continue
                </p>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="m-sm-4">
                        <form>
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input class="form-control form-control-lg" wire:model="username" type="text"
                                    name="username" placeholder="Enter your username" />
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input class="form-control form-control-lg" type="password" wire:model="password"
                                    name="password" placeholder="Enter your password" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($user_yoq): ?>
                                <span style="color: red">Bunday foydalanuvchi topilmadi</span>
                            <?php endif; ?>
                            <?php if($null): ?>
                                <span style="color: red">Bunday foydalanuvchi topilmadi</span>
                            <?php endif; ?>
                            <div class="text-center mt-3">
                                <button type="button" wire:click="login" class="btn btn-lg btn-primary">Sign
                                    in</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/livewire/login.blade.php ENDPATH**/ ?>
<div class="row">

<div class="col-lg-9">
    <?php
   $a=\App\Models\About::find(1);
 ?>
    <div class="blog-section p-0 posts-page">
            <div class="blog-posts">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog-post">
                    <div class="blog-thumbnail">
                        <a href="" title="">
                            <img src="<?php echo e(asset('images/'.$blog->image)); ?>" alt="" class="w-100">
                        </a>
                        <span class="category"> <?php echo e($blog->category->name); ?>, <?php echo e($a->name); ?></span></div>
                    <div class="blog-info">
                        <ul class="meta">
                            <li><a href="blog.html#" title=""><?php echo e($blog->created_at->format('d/m/Y')); ?></a></li>
                            <li><a href="blog.html#" title="">by Admin</a></li>
                            <li><img src="assets/img/icon13.png" alt="">
                                <a href="" title=""><?php echo e($blog->category->name); ?>,</a><a href="blog.html#" title=""> School</a>
                            </li>
                        </ul>
                        <h3 class="stick"><a href="<?php echo e(route('blog.show',$blog->id)); ?>" title=""><?php echo e($blog->title); ?></a></h3>
                        <p><?php echo e($blog->description); ?></p>
                        <a href="<?php echo e(route('blog.show',$blog->id)); ?>" title="" class="read-more">Ko`rish <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

    </div>
    <!--blog-section end-->

    <!--pagination-end-->
</div>

    <div class="col-lg-3">
        <div class="sidebar">

            <!--widget-search end-->
            <div class="widget widget-categories">
                <h3 class="widget-title">Categories</h3>
                <ul>
                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="blog.html#" title=""><?php echo e($c->name); ?></a> <span><?php echo e(count($c->blogs->ToArray())); ?></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <!--widget-categories end-->
            <div class="widget widget-posts">
                <h3 class="widget-title">Ohirgi yangiliklar</h3>
                <div class="wd-posts">
                    <?php $__currentLoopData = \App\Models\Blog::take(3)->orderByDesc('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="wd-post d-flex flex-wrap">
                            <div class="wd-thumb"><img style="width: 52px;height: 52px;border-radius: 18%" src="<?php echo e(asset('images/'.$b->image)); ?>" alt=""></div>
                            <div class="wd-info">
                                <h3><a href="<?php echo e(route('blog.show',$b->id)); ?>" title=""><?php echo e($b->title); ?></a></h3>
                                <span><?php echo e($b->created_at->format('d/m/y')); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!--wd-posts end-->
            </div>


            <!--widget-archives end-->
            <div class="widget widget-tags">
                <h3 class="widget-title">Turlar</h3>
                <ul>
                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><a wire:click="category(<?php echo e($c->id); ?>)" title=""><?php echo e($c->name); ?></a></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     <li><a wire:click="category(0)" title="">hammasi</a></li>

                </ul>
            </div>
            <!--widget-tags end-->
            <div class="widget widget-calendar">
                <h3 class="widget-title">Calendar</h3>
                <div class="mdp-calendar">
                    <h3 class="month"> <?php echo e(now()->format('d M Y')); ?></h3>

































































                </div>
                <!--mdp-calendar end-->
            </div>
            <!--widget-calendar end-->
        </div>
        <!--sidebar end-->
    </div>
</div>
<?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/livewire/blog-index.blade.php ENDPATH**/ ?>
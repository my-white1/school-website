<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="d-flex">
                    <div class="card flex-fill">
                        <div class="card-header">
                            <h5 class="card-title 0">Maktab ma'lumotlarini ko'rish</h5>
                        </div>
                        <table class="table table-hover my-0">
                            <tr>
                                <th>Maktab nomi</th>
                                <td><?php echo e($about->name); ?></td>
                            </tr>
                            <tr>
                                <th>Telefon raqam</th>
                                <td><?php echo e($about->phone_number); ?></td>
                            </tr>
                            <tr>
                                <th>Ma'lumotlari</th>
                                <td><?php echo e($about->description); ?></td>
                            </tr>
                            <tr>
                                <th>Joylashgan viloyati</th>
                                <td><?php echo e($about->viloyat); ?></td>
                            </tr>
                            <tr>
                                <th>Joylashgan tumani</th>
                                <td><?php echo e($about->tuman); ?></td>
                            </tr>
                            <tr>
                                <th>Darslar boshlanish vaqti</th>
                                <td><?php echo e($about->start_time); ?></td>
                            </tr>
                            <tr>
                                <th>Darslar tugash vaqti</th>
                                <td><?php echo e($about->end_time); ?></td>
                            </tr>
                            <tr>
                                <th>Facebook</th>
                                <td><?php echo e($about->facebook); ?></td>
                            </tr>
                            <tr>
                                <th>Instagram</th>
                                <td><?php echo e($about->instagram); ?></td>
                            </tr>
                            <tr>
                                <th>Rasimi</th>
                                <td><img width="100px" src="<?php echo e(asset("images/$about->image")); ?>"
                                         alt="Maktab rasimi"></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <a class="btn btn-secondary mt-3" href="<?php echo e(route('abouts.index')); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                     class="bi bi-arrow-left" viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                          d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                </svg>
                Orqaga
            </a>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/admin/about/show.blade.php ENDPATH**/ ?>
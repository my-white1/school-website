<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-certificate')->html();
} elseif ($_instance->childHasBeenRendered('XXlw26A')) {
    $componentId = $_instance->getRenderedChildComponentId('XXlw26A');
    $componentTag = $_instance->getRenderedChildComponentTagName('XXlw26A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XXlw26A');
} else {
    $response = \Livewire\Livewire::mount('create-certificate');
    $html = $response->html();
    $_instance->logRenderedChild('XXlw26A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/admin/certificate/create.blade.php ENDPATH**/ ?>
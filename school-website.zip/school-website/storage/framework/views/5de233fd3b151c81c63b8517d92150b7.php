<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="d-flex">
                    <div class="card flex-fill">
                        <div class="card-header">

                            <h5 class="card-title 0">Maktablar haqida</h5>
                                <a href="<?php echo e(route('users.create')); ?>"
                                   class="btn btn-success">Yaratish</a>


                        </div>
                        <table class="table table-hover my-0">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Ism</th>
                                <th>Foydalanuvchi nomi</th>
                                <th class="d-none d-xl-table-cell">Maktabi</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $school=\App\Models\About::find($user->school_id);
                                    ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->username); ?></td>
                                        <?php if($school): ?>
                                        <td class="d-none d-md-table-cell"><?php echo e($school->name); ?></td>
                                        <?php else: ?>
                                            <?php if($user->school_id==null): ?>
                                                <td class="d-none d-md-table-cell">Ega</td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(route('users.edit',[$user->id])); ?>"
                                               class="btn btn-info">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/admin/users/index.blade.php ENDPATH**/ ?>
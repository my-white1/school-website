<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="d-flex">
                    <div class="card flex-fill">
                        <div class="card-header">
                              <?php if(auth()->user()->school_id==null): ?>
                            <h5 class="card-title 0">Maktablar haqida</h5>
                                <a href="<?php echo e(route('abouts.create')); ?>"
                                   class="btn btn-success">yaratish</a>
                            <?php else: ?>
                            <h5 class="card-title 0">Maktab haqida</h5>
                              <?php endif; ?>


                        </div>
                        <table class="table table-hover my-0">
                            <thead>
                            <tr>
                                <th>Maktab nomi</th>
                                <th class="d-none d-xl-table-cell">Rasimi</th>
                                <th>Telefon raqam</th>
                                <th class="d-none d-xl-table-cell">Joylashgan viloyati</th>
                                <th class="d-none d-xl-table-cell">Joylashgan tumani</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(auth()->user()->school_id==null): ?>
                                <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($about->name); ?></td>
                                        <td class="d-none d-xl-table-cell"><img width="100px"
                                                                                src="<?php echo e('images/'.$about->image); ?>"
                                                                                alt="<?php echo e($about->name); ?> rasimi"></td>
                                        <td><?php echo e($about->phone_number); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($about->viloyat); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($about->tuman); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('abouts.edit',[$about->id])); ?>"
                                               class="btn btn-info">Edit</a>
                                            <a href="<?php echo e(route('abouts.show',[$about->id])); ?>"
                                               class="btn btn-success">View</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php
                                    $about2=App\Models\About::find(auth()->user()->school_id)
                                ?>
                                <tr>
                                    <td><?php echo e($about2->name); ?></td>
                                    <td class="d-none d-xl-table-cell"><img width="100px"
                                                                            src="<?php echo e('images/'.$about2->image); ?>"
                                                                            alt="<?php echo e($about2->name); ?> rasimi"></td>
                                    <td><?php echo e($about2->phone_number); ?></td>
                                    <td class="d-none d-md-table-cell"><?php echo e($about2->viloyat); ?></td>
                                    <td class="d-none d-md-table-cell"><?php echo e($about2->tuman); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('abouts.edit',[$about2->id])); ?>"
                                           class="btn btn-info">Edit</a>
                                        <a href="<?php echo e(route('abouts.show',[$about2->id])); ?>"
                                           class="btn btn-success">View</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/admin/about/index.blade.php ENDPATH**/ ?>
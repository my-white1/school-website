<?php $__env->startSection('content'); ?>
    <?php
        $a=\App\Models\About::find(1);
    ?>
    <section class="pager-section">
        <div class="container">
            <div class="pager-content text-center">
                <h2>Blog</h2>
                <ul>
                    <li><a href="blog.html#" title="">Home</a></li>
                    <li><span>Blog</span></li>
                </ul>
            </div>
            <!--pager-content end-->

        </div>
    </section>
    <!--pager-section end-->
    <section class="page-content">
        <div class="container">
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-index')->html();
} elseif ($_instance->childHasBeenRendered('4z5U0Xq')) {
    $componentId = $_instance->getRenderedChildComponentId('4z5U0Xq');
    $componentTag = $_instance->getRenderedChildComponentTagName('4z5U0Xq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4z5U0Xq');
} else {
    $response = \Livewire\Livewire::mount('blog-index');
    $html = $response->html();
    $_instance->logRenderedChild('4z5U0Xq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



        </div>
    </section>
    <!--page-content end-->
    <!--newsletter-sec end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/frontend/blog/index.blade.php ENDPATH**/ ?>
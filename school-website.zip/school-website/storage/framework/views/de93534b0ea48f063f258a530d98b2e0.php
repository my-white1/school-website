<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
          content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="img/icons/icon-48x48.png"/>

    <link rel="canonical" href="https://demo-basic.adminkit.io/pages-sign-in.html"/>

    <title>Sign In | AdminKit Demo</title>

    <link href="<?php echo e(asset('back/css/app.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</head>

<body>
<main class="d-flex w-100">
    <div class="container d-flex flex-column">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login')->html();
} elseif ($_instance->childHasBeenRendered('4xnw4p1')) {
    $componentId = $_instance->getRenderedChildComponentId('4xnw4p1');
    $componentTag = $_instance->getRenderedChildComponentTagName('4xnw4p1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4xnw4p1');
} else {
    $response = \Livewire\Livewire::mount('login');
    $html = $response->html();
    $_instance->logRenderedChild('4xnw4p1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</main>
<script src="<?php echo e(asset('back/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/admin/login.blade.php ENDPATH**/ ?>
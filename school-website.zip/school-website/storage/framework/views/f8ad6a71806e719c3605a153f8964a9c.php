<?php $__env->startSection('content'); ?>
       <?php
      $a=\App\Models\About::find(1);
        ?>
    <section style="background-image: url(<?php echo e(asset("images/$blog->image")); ?>);" class="pager-section blog-version">
        <div class="container">
            <div class="pager-content text-center">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>" title="">Home</a></li>
                    <li><a href="<?php echo e(route('blog.index')); ?>" title="">Blog</a></li>
                    <li><span> <?php echo e($blog->title); ?> </span></li>
                </ul>
                <h2><?php echo e($blog->title); ?></h2><span class="categry"> <?php echo e($blog->category->name); ?>, <?php echo e($a->name); ?></span>
                <ul class="meta">
                    <li><a href="" title=""><?php echo e($blog->created_at->format('d/m/y')); ?></a></li>
                    <li><a href="" title="">by Admin</a></li>
                    <li><img src="" alt=""><a href="" title=""><?php echo e($blog->category->name); ?>,</a><a href="" title=""> maktab</a></li>
                </ul>
            </div><!--pager-content end-->
        </div>
    </section><!--pager-section end-->
<section class="page-content p80">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <div class="blog-post single">
                    <p><?php echo e($blog->description); ?></p>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="oderd">
                                <h3>Tartibsiz jadval</h3>
                                <ul>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                </ul>
                            </div>
                            <!--ordrd end-->
                        </div>
                        <div class="col-md-6">
                            <div class="oderd">
                                <h3>Tartibsiz jadval</h3>
                                <ol>
                                    <li>1. Etiam ante nisl, maximus vitae sem non, dignissim</li>
                                    <li>2. Donec blandit, sapien eu porttitor blandit</li>
                                    <li>3. Sed at urna at massa viverra feugiat non</li>
                                </ol>
                            </div>
                            <!--ordrd end-->
                        </div>
                    </div>


                </div>
                <!--blog-post single end-->

                <!--mdp-contact end-->
            </div>
            <div class="col-lg-3">
                <div class="sidebar">

                    <!--widget-search end-->
                    <div class="widget widget-categories">
                        <h3 class="widget-title">Categories</h3>
                        <ul>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="blog.html#" title=""><?php echo e($c->name); ?></a> <span><?php echo e(count($c->blogs->ToArray())); ?></span></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                    <!--widget-categories end-->
                    <div class="widget widget-posts">
                        <h3 class="widget-title">Ohirgi yangiliklar</h3>
                        <div class="wd-posts">
                            <?php $__currentLoopData = \App\Models\Blog::take(3)->orderByDesc('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="wd-post d-flex flex-wrap">
                                    <div class="wd-thumb"><img style="width: 52px;height: 52px;border-radius: 18%" src="<?php echo e(asset('images/'.$b->image)); ?>" alt=""></div>
                                    <div class="wd-info">
                                        <h3><a href="<?php echo e(route('blog.show',$b->id)); ?>" title=""><?php echo e($b->title); ?></a></h3>
                                        <span><?php echo e($b->created_at->format('d/m/y')); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!--wd-posts end-->
                    </div>


                    <!--widget-archives end-->
                    <div class="widget widget-tags">
                        <h3 class="widget-title">Turlar</h3>
                        <ul>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a wire:click="category(<?php echo e($c->id); ?>)" title=""><?php echo e($c->name); ?></a></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <li><a wire:click="category(0)" title="">hammasi</a></li>

                        </ul>
                    </div>
                    <!--widget-tags end-->
                    <div class="widget widget-calendar">
                        <h3 class="widget-title">Calendar</h3>
                        <div class="mdp-calendar">
                            <h3 class="month"> <?php echo e(now()->format('d M Y')); ?></h3>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                        <!--mdp-calendar end-->
                    </div>
                    <!--widget-calendar end-->
                </div>
            </div>
        </div>
    </div>
</section>
<!--newsletter-sec end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/frontend/blog/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php
        $a = \App\Models\About::find(1);
    ?>
    <section class="pager-section">
        <div class="container">
            <div class="pager-content text-center">
                <h2>Sinflar</h2>
                <ul>
                    <li><a href="classes.html#" title="">Bosh sahifa</a></li>
                    <li><span>Sinflar</span></li>
                </ul>
            </div>
            <!--pager-content end-->
            
        </div>
    </section>
    <!--pager-section end-->
    <section class="classes-page">
        <div class="container">
            <div class="classes-banner"><span>Hoziroq sinab ko'ring</span>
                <h2>O'zinggizga sarmoya kiriting</h2><a href="<?php echo e(route('classes.index')); ?>" title="" class="btn-default">Sinflar <i
                        class="fa fa-long-arrow-alt-right"></i></a>
            </div>
            <!--classes-banner end-->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('fronend.classes-table')->html();
} elseif ($_instance->childHasBeenRendered('2DBOdV2')) {
    $componentId = $_instance->getRenderedChildComponentId('2DBOdV2');
    $componentTag = $_instance->getRenderedChildComponentTagName('2DBOdV2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2DBOdV2');
} else {
    $response = \Livewire\Livewire::mount('fronend.classes-table');
    $html = $response->html();
    $_instance->logRenderedChild('2DBOdV2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>
    <!--classes-page end-->
    <!--newsletter-sec end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmadullo/Desktop/proyects/school-website/school-website/resources/views/frontend/classes/index.blade.php ENDPATH**/ ?>
@extends('layouts.frontend')

@section('content')

    <!--page-content end-->
    <!--newsletter-sec end-->
@endsection

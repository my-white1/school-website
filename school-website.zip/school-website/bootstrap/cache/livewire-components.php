<?php return array (
  'blog-index' => 'App\\Http\\Livewire\\BlogIndex',
  'course-index' => 'App\\Http\\Livewire\\CourseIndex',
  'create-certificate' => 'App\\Http\\Livewire\\CreateCertificate',
  'fronend.classes-table' => 'App\\Http\\Livewire\\Fronend\\ClassesTable',
  'frontend.students-table' => 'App\\Http\\Livewire\\Frontend\\StudentsTable',
  'frontend.teachers-table' => 'App\\Http\\Livewire\\Frontend\\TeachersTable',
  'login' => 'App\\Http\\Livewire\\Login',
);